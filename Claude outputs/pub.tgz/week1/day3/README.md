[🏠 과정 목차](../../README.md) › [1주차](../README.md) › [3일차](README.md)

# 1주차 3일차 — 네트워크 기초

📕 1주차 이북 PDF: [보기](../../downloads/pdf/week1.pdf) · [내려받기](https://github.com/niceguy61/kdt_devops_lecture_2026_rev2/raw/main/downloads/pdf/week1.pdf) &nbsp;|&nbsp; 📊 3일차 슬라이드: [PPTX 내려받기](https://github.com/niceguy61/kdt_devops_lecture_2026_rev2/raw/main/downloads/pptx/week1-day3.pptx)

## 오늘의 목표

클라우드는 결국 "네트워크로 연결된 남의 컴퓨터"입니다. Docker 컨테이너끼리 통신하는 것도, Kubernetes 서비스가 서로를 찾는 것도, AWS VPC를 설계하는 것도 모두 오늘 배우는 네트워크 위에 서 있습니다. 2주차 이후 실습에서 만나는 에러의 상당수가 **"연결이 안 돼요"**이고, 그 원인은 거의 항상 **주소(IP), 문(포트), 이름(DNS), 규칙(방화벽)** 중 하나입니다. 오늘은 그 네 가지를 구분하는 눈을 만듭니다.

- 네트워크 계층 모델을 택배에 비유해 설명할 수 있습니다.
- IP 주소와 CIDR 표기(`10.0.0.0/16`)를 읽고, 공인·사설 IP를 구분합니다.
- 포트와 TCP/UDP의 차이를 알고, `localhost`와 `0.0.0.0`의 의미를 압니다.
- DNS가 도메인을 IP로 바꾸는 과정을 설명할 수 있습니다.
- HTTP 요청·응답과 상태 코드를 읽고, HTTPS가 무엇을 보호하는지 압니다.
- 브라우저에서 데이터베이스까지 요청이 거치는 길을 그림으로 설명합니다.
- 라우터, 방화벽, NAT, 프록시, 로드밸런서의 역할을 AWS·Kubernetes와 연결합니다.

## 시간표

| 교시 | 주제 |
|---|---|
| 1교시 | 어제 10분 요약 + 네트워크 큰 그림 |
| 2교시 | IP 주소와 서브넷 |
| 3교시 | 포트와 프로토콜 |
| 4교시 | DNS |
| 5교시 | HTTP와 HTTPS |
| 6교시 | 서비스로 가는 길 — 요청의 여정 |
| 7교시 | 네트워크 장비의 역할 |
| 8교시 | 배움일기 |

## 오늘의 키워드

`패킷` `캡슐화` `OSI` `TCP/IP` `IP 주소` `CIDR` `서브넷` `사설 IP` `NAT` `포트` `TCP` `UDP` `3-way handshake` `localhost` `DNS` `TTL` `HTTP` `상태 코드` `TLS` `인증서` `CDN` `로드밸런서` `방화벽` `리버스 프록시`

## 교시별 자료

1. [네트워크 큰 그림](lesson-01.md)
2. [IP 주소와 서브넷](lesson-02.md)
3. [포트와 프로토콜](lesson-03.md)
4. [DNS](lesson-04.md)
5. [HTTP와 HTTPS](lesson-05.md)
6. [서비스로 가는 길](lesson-06.md)
7. [네트워크 장비의 역할](lesson-07.md)

---

⬅️ 이전: [7교시 · VM에서 컨테이너로 (2주차 예고)](../day2/lesson-07.md) &nbsp;|&nbsp; 다음: [1교시 · 네트워크 큰 그림](lesson-01.md) ➡️
