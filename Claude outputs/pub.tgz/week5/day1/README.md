[🏠 과정 목차](../../README.md) › [5주차](../README.md) › [1일차](README.md)

# 5주차 1일차 — AWS 계정과 VPC

📕 5주차 이북 PDF: [보기](../../downloads/pdf/week5.pdf) · [내려받기](https://github.com/niceguy61/kdt_devops_lecture_2026_rev2/raw/main/downloads/pdf/week5.pdf) &nbsp;|&nbsp; 📊 1일차 슬라이드: [PPTX 내려받기](https://github.com/niceguy61/kdt_devops_lecture_2026_rev2/raw/main/downloads/pptx/week5-day1.pptx)

## 오늘의 목표

4주차 마지막 배움일기의 질문은 "클라우드의 클러스터는 **누가, 어떤 네트워크 위에, 얼마의 비용으로** 만드는가?"였습니다. 이번 주는 그 답을 직접 만듭니다 — 오늘은 **누가**(계정과 신원)와 **어떤 네트워크**(VPC), 그리고 **얼마**(비용을 지키는 장치)입니다.

- kind에서 AWS로 옮길 때 **무엇이 바뀌고 무엇이 그대로인지** 정리합니다.
- AWS 계정을 만들고 **루트 사용자**를 잠그고, **예산 알림**을 겁니다.
- **IAM** 사용자 · 그룹 · 역할 · 정책을 4주차 RBAC와 비교하며 익히고, 매일 쓸 관리자 사용자를 만듭니다.
- **AWS CLI**에 접속 키 없이 `aws login`으로 로그인합니다.
- **VPC** · 서브넷 · 라우팅 테이블 · 인터넷 게이트웨이 · NAT를 이해하고, 콘솔로 DevMart용 VPC를 만듭니다.
- **보안 그룹**과 **네트워크 ACL**을 구분합니다.

## 시간표

| 교시 | 주제 | 실습 결과물 |
|---|---|---|
| 1교시 | 4주차 요약 + 노트북에서 클라우드로 | 이번 주 비용 계산표 |
| 2교시 | 계정 만들기와 루트 지키기 | 루트 MFA, 예산 알림 둘 |
| 3교시 | IAM — 사용자 · 그룹 · 역할 · 정책 | `devops-admin` 사용자, 정책 읽기 |
| 4교시 | AWS CLI와 aws login | 키 없이 로그인한 CLI |
| 5교시 | VPC의 구성 요소 | 내 VPC 설계도 |
| 6교시 | 콘솔로 VPC 만들기 | `devmart-vpc` (서브넷 4 · 라우팅 테이블 3) |
| 7교시 | 보안 그룹 · NACL + 비용 점검 | 보안 그룹 하나, 남은 것 확인 |
| 8교시 | 배움일기 | |

## 교시별 자료

1. [4주차 요약 + 노트북에서 클라우드로](lesson-01.md)
2. [계정 만들기와 루트 지키기](lesson-02.md)
3. [IAM — 사용자 · 그룹 · 역할 · 정책](lesson-03.md)
4. [AWS CLI와 aws login](lesson-04.md)
5. [VPC의 구성 요소](lesson-05.md)
6. [콘솔로 VPC 만들기](lesson-06.md)
7. [보안 그룹 · NACL + 비용 점검](lesson-07.md)

> [!IMPORTANT]
> **오늘 실습 전에 준비할 것**
>
> - **본인 명의의 신용 · 체크카드**(해외 결제 가능)와 **휴대폰**(문자 · 인증 앱). 계정 확인용으로 1달러 정도가 잠깐 승인되었다 취소될 수 있습니다.
> - 인증 앱(Google Authenticator · Microsoft Authenticator 등) 또는 패스키를 쓸 수 있는 기기.
> - 회사 · 학교의 공용 계정이 아니라 **나만의 새 계정**을 만듭니다. 이번 주 모든 실습은 각자의 계정에서 하고, **그날 만든 것은 그날 지웁니다.**
> - 실습 파일은 강의 저장소의 `labs/week5/day1/`입니다.

---

⬅️ 이전: [7교시 · 4주차 회고 + 보안 점검표](../../week4/day5/lesson-07.md) &nbsp;|&nbsp; 다음: [1교시 · 4주차 요약 + 노트북에서 클라우드로](lesson-01.md) ➡️
