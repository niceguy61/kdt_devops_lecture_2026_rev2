[🏠 과정 목차](../../README.md) › [5주차](../README.md) › [2일차](README.md)

# 5주차 2일차 — EC2 · ALB · Auto Scaling · S3

📕 5주차 이북 PDF: [보기](../../downloads/pdf/week5.pdf) · [내려받기](https://github.com/niceguy61/kdt_devops_lecture_2026_rev2/raw/main/downloads/pdf/week5.pdf) &nbsp;|&nbsp; 📊 2일차 슬라이드: [PPTX 내려받기](https://github.com/niceguy61/kdt_devops_lecture_2026_rev2/raw/main/downloads/pptx/week5-day2.pptx)

## 오늘의 목표

어제 배움일기의 마지막 질문은 "비어 있는 VPC에 **서버를 띄우고, 여러 대로 늘리고, 하나가 죽어도 손님이 모르게** 하려면 무엇이 필요할까?"였습니다. 오늘은 그것을 **콘솔로** 직접 만듭니다. 3 · 4주차에 Kubernetes가 해 주던 일 — 원하는 수 유지, 상태 검사, 입구 하나 — 을 **가상 서버 크기**로 다시 만나는 날입니다.

- AWS의 컴퓨트 선택지(EC2 · ECS · Lambda · EKS)를 구분합니다.
- **IAM 역할**을 붙인 EC2를 띄우고, **user data**로 podinfo를 자동 실행합니다.
- **Session Manager**로 포트 없이 접속하고, 서버 안에서 **키 없이** S3를 읽습니다.
- **시작 템플릿 + Auto Scaling 그룹**으로 "원하는 수 2"를 만듭니다.
- **대상 그룹 + ALB**로 입구 하나를 만들고, 서버를 죽여 **교체**되는 것을 봅니다.
- 만든 것을 **의존 순서대로** 지웁니다.

## 시간표

| 교시 | 주제 | 실습 결과물 |
|---|---|---|
| 1교시 | 1일차 요약 + 컴퓨트 고르기 | 오늘의 그림 |
| 2교시 | 역할을 붙인 첫 EC2 | `devmart-web-1` (podinfo) |
| 3교시 | Session Manager · 메타데이터 · S3 | 포트 없는 접속, 키 없는 S3 읽기 |
| 4교시 | 시작 템플릿과 Auto Scaling 그룹 | `devmart-asg` (원하는 수 2) |
| 5교시 | 대상 그룹과 ALB | 주소 하나로 두 서버 |
| 6교시 | 장애와 교체 · 늘리기 | 죽은 서버가 바뀌는 시간 |
| 7교시 | 지우는 순서 + 비용 점검 | 깨끗한 계정 |
| 8교시 | 배움일기 | |

## 교시별 자료

1. [1일차 요약 + 컴퓨트 고르기](lesson-01.md)
2. [역할을 붙인 첫 EC2](lesson-02.md)
3. [Session Manager · 메타데이터 · S3](lesson-03.md)
4. [시작 템플릿과 Auto Scaling 그룹](lesson-04.md)
5. [대상 그룹과 ALB](lesson-05.md)
6. [장애와 교체 · 늘리기](lesson-06.md)
7. [지우는 순서 + 비용 점검](lesson-07.md)

> [!IMPORTANT]
> **오늘 실습 전에 확인할 것**
>
> - 어제의 `devmart-vpc`와 보안 그룹 `devmart-web-sg` · `devmart-app-sg`가 있어야 합니다.
> - `aws login`이 살아 있어야 합니다: `aws sts get-caller-identity` → `user/devops-admin`.
> - 오늘은 **시간당 요금이 나가는 것**(EC2 · ALB · 공인 IP)을 만듭니다. **7교시에 반드시 지웁니다.** 하루 합계 약 $0.5 이하입니다.
> - 실습 파일은 강의 저장소의 `labs/week5/day2/`입니다.

---

⬅️ 이전: [7교시 · 보안 그룹 · NACL + 비용 점검](../day1/lesson-07.md) &nbsp;|&nbsp; 다음: [1교시 · 1일차 요약 + 컴퓨트 고르기](lesson-01.md) ➡️
